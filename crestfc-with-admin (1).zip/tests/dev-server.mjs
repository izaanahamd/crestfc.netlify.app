// TEST ONLY. Runs the website and the real backend function together on this machine, like Netlify does.
// Start it with:  node --import ./tests/register.mjs tests/dev-server.mjs
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import handler from '../netlify/functions/api.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const SITE = path.join(ROOT, 'site');
const PORT = Number(process.env.PORT || 8888);
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.webp': 'image/webp', '.txt': 'text/plain; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml' };

// Read the security headers from netlify.toml so the tests run under the same rules as the real site.
const toml = fs.existsSync(path.join(ROOT, 'netlify.toml')) ? fs.readFileSync(path.join(ROOT, 'netlify.toml'), 'utf8') : '';
const csp = (toml.match(/Content-Security-Policy\s*=\s*"([^"]+)"/) || [])[1];

http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  try {
    if (url.pathname.startsWith('/api/')) {
      const chunks = [];
      for await (const c of req) chunks.push(c);
      const body = chunks.length ? Buffer.concat(chunks) : undefined;
      const request = new Request(url, { method: req.method, headers: req.headers, body: ['GET', 'HEAD'].includes(req.method) ? undefined : body });
      const ip = req.headers['x-test-ip'] || req.socket.remoteAddress;
      const response = await handler(request, { ip });
      const headers = {};
      response.headers.forEach((v, k) => { headers[k] = v; });
      const setCookie = response.headers.getSetCookie ? response.headers.getSetCookie() : [];
      if (setCookie.length) headers['set-cookie'] = setCookie;
      res.writeHead(response.status, headers);
      res.end(Buffer.from(await response.arrayBuffer()));
      return;
    }
    let p = decodeURIComponent(url.pathname);
    if (p === '/admin') { res.writeHead(301, { location: '/admin/' }); res.end(); return; }
    if (p.endsWith('/')) p += 'index.html';
    let file = path.join(SITE, p);
    if (!file.startsWith(SITE)) { res.writeHead(403); res.end(); return; }
    if (!fs.existsSync(file) && fs.existsSync(file + '.html')) file += '.html';
    if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); res.end('Not found'); return; }
    const headers = { 'content-type': TYPES[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-cache' };
    if (p.startsWith('/admin/')) { if (csp) headers['content-security-policy'] = csp; headers['x-frame-options'] = 'DENY'; }
    res.writeHead(200, headers);
    fs.createReadStream(file).pipe(res);
  } catch (e) {
    console.error(e);
    res.writeHead(500); res.end('Server error');
  }
}).listen(PORT, () => console.log(`Local test server on http://localhost:${PORT}`));
