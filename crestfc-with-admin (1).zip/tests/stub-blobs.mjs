// TEST ONLY. A stand-in for Netlify's storage that saves to a local folder, so the real backend code can run on this machine.
// It copies the few functions the backend uses: get, set, setJSON, delete. It is not part of the website.
import fs from 'node:fs';
import path from 'node:path';

const ROOT = process.env.STUB_BLOBS_DIR || path.join(import.meta.dirname, '.data');

export function getStore(options) {
  const name = typeof options === 'string' ? options : options.name;
  const dir = path.join(ROOT, name);
  fs.mkdirSync(dir, { recursive: true });
  const file = (key) => path.join(dir, encodeURIComponent(key));
  return {
    async get(key, opts = {}) {
      let text;
      try { text = fs.readFileSync(file(key), 'utf8'); } catch { return null; }
      return opts.type === 'json' ? JSON.parse(text) : text;
    },
    async set(key, value) { fs.writeFileSync(file(key), String(value)); },
    async setJSON(key, value) { fs.writeFileSync(file(key), JSON.stringify(value)); },
    async delete(key) { try { fs.unlinkSync(file(key)); } catch { /* already gone */ } },
  };
}
