// The website's backend. One function answers every /api/... address.
import { adminConfig, attemptLogin, clearCookie, clientIp, isAdmin, sessionCookie } from '../lib/auth.mjs';
import {
  CONTENT_FIELDS, DEFAULT_PLAYERS, JERSEY_COLOURS, LIMITS, MATCH_STATUSES, MATCH_VENUE_TYPES, POSITIONS,
} from '../lib/schema.mjs';
import { ConflictError, readDoc, writeDoc } from '../lib/store.mjs';
import { ValidationError, validateContent, validateMatches, validatePlayers } from '../lib/validate.mjs';

const MAX_BODY = 200_000;

function json(body, status = 200, headers = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff',
      ...headers,
    },
  });
}

async function readJson(req) {
  const raw = await req.text();
  if (raw.length > MAX_BODY) throw new ValidationError('That request is too large.');
  try { return JSON.parse(raw || '{}'); } catch { throw new ValidationError('That request was not valid.'); }
}

// Blocks requests that did not come from this website's own pages.
function sameSiteOrThrow(req) {
  const type = req.headers.get('content-type') || '';
  if (!type.toLowerCase().includes('application/json')) return json({ error: 'bad_request', message: 'Unsupported request.' }, 415);
  const fetchSite = req.headers.get('sec-fetch-site');
  if (fetchSite && !['same-origin', 'none'].includes(fetchSite)) return json({ error: 'forbidden', message: 'Blocked.' }, 403);
  const origin = req.headers.get('origin');
  if (!origin) return json({ error: 'forbidden', message: 'Blocked.' }, 403);
  let originHost;
  try { originHost = new URL(origin).host; } catch { return json({ error: 'forbidden', message: 'Blocked.' }, 403); }
  const allowed = new Set([new URL(req.url).host, req.headers.get('host'), req.headers.get('x-forwarded-host')].filter(Boolean));
  if (!allowed.has(originHost)) return json({ error: 'forbidden', message: 'Blocked.' }, 403);
  return null;
}

async function publicData() {
  const [players, matches, content] = await Promise.all([
    readDoc('players', DEFAULT_PLAYERS), readDoc('matches', []), readDoc('content', {}),
  ]);
  return {
    players: players.data,
    matches: matches.data,
    content: content.data,
    rev: { players: players.rev, matches: matches.rev, content: content.rev },
  };
}

async function save(req, key, validator, fallback) {
  const body = await readJson(req);
  if (!Number.isInteger(body.rev)) throw new ValidationError('Reload the page and try again.');
  const data = validator(body.data);
  const doc = await writeDoc(key, data, body.rev, fallback);
  return json({ ok: true, rev: doc.rev, data: doc.data });
}

export default async (req, context) => {
  try {
    const url = new URL(req.url);
    const route = url.pathname.replace(/\/+$/, '');
    const method = req.method;

    if (route === '/api/content' && method === 'GET') {
      return json(await publicData());
    }

    if (route === '/api/schema' && method === 'GET') {
      return json({
        fields: CONTENT_FIELDS, positions: POSITIONS, limits: LIMITS,
        matchStatuses: MATCH_STATUSES, venueTypes: MATCH_VENUE_TYPES, jerseyColours: JERSEY_COLOURS,
      });
    }

    if (route === '/api/session' && method === 'GET') {
      const cfg = adminConfig();
      return json({ configured: cfg.ok, authenticated: cfg.ok ? await isAdmin(req) : false });
    }

    if (route === '/api/login' && method === 'POST') {
      const blocked = sameSiteOrThrow(req);
      if (blocked) return blocked;
      const body = await readJson(req);
      const email = typeof body.email === 'string' ? body.email.slice(0, 200) : '';
      const password = typeof body.password === 'string' ? body.password.slice(0, 200) : '';
      const result = await attemptLogin({ email, password, ip: clientIp(req, context) });
      if (result.status === 'ok') {
        return json({ ok: true }, 200, { 'set-cookie': sessionCookie(result.token, req) });
      }
      if (result.status === 'locked') {
        return json({ error: 'locked', message: 'Too many wrong attempts. Please wait 15 minutes and try again.', retryAfter: result.retryAfter }, 429, { 'retry-after': String(result.retryAfter) });
      }
      if (result.status === 'not_configured') {
        return json({ error: 'not_configured', message: 'The admin login is not set up yet. Follow the setup guide to add the email and password in Netlify.' }, 503);
      }
      return json({ error: 'invalid', message: 'Incorrect email or password.' }, 401);
    }

    if (route === '/api/logout' && method === 'POST') {
      const blocked = sameSiteOrThrow(req);
      if (blocked) return blocked;
      return json({ ok: true }, 200, { 'set-cookie': clearCookie(req) });
    }

    if (route.startsWith('/api/admin/')) {
      if (method !== 'PUT') return json({ error: 'method_not_allowed' }, 405);
      if (!(await isAdmin(req))) return json({ error: 'unauthorized', message: 'Please sign in again.' }, 401);
      const blocked = sameSiteOrThrow(req);
      if (blocked) return blocked;
      if (route === '/api/admin/players') return await save(req, 'players', validatePlayers, DEFAULT_PLAYERS);
      if (route === '/api/admin/matches') return await save(req, 'matches', validateMatches, []);
      if (route === '/api/admin/content') return await save(req, 'content', validateContent, {});
    }

    return json({ error: 'not_found' }, 404);
  } catch (err) {
    if (err instanceof ValidationError) return json({ error: 'validation', message: err.message }, 400);
    if (err instanceof ConflictError) {
      return json({ error: 'conflict', message: 'Someone else saved a change first. The latest version has been loaded.', current: { rev: err.current.rev, data: err.current.data } }, 409);
    }
    console.error('API error', err);
    return json({ error: 'server_error', message: 'Something went wrong on the server. Please try again.' }, 500);
  }
};

export const config = { path: '/api/*' };
