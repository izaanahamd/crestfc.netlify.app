/* Draws a CrestFC back-of-shirt: a blank shirt photo with the player's name and number on top.
   The public website and the admin preview both use this file, so they always look the same. */
(function () {
  'use strict';
  var NS = 'http://www.w3.org/2000/svg';
  var XL = 'http://www.w3.org/1999/xlink';
  var ROOT = (function () {
    try { return new URL('.', document.currentScript.src).href; } catch (e) { return '/'; }
  })();
  var BASES = { burgundy: 'img/jersey-burgundy.webp', green: 'img/jersey-green.webp' };
  var RING = { burgundy: '#2e0e16', green: '#0c2214' };
  var CREAM = '#d9c1a0';
  var FONT = "Poppins, 'Helvetica Neue', Arial, sans-serif";
  var W = 790, H = 980, CX = 400;
  var NAME_SIZE = 32.35, NAME_TRACK = 4.53, NAME_MAX = 234, NAME_Y = 227;     // name sits at the same size on every shirt
  var NUM_SIZE = 340, NUM_BASE = 542, NUM_SQUEEZE = 0.8;
  var all = [];
  var uid = 0;
  var ctx = null;

  function node(tag, attrs) {
    var n = document.createElementNS(NS, tag);
    for (var k in attrs) { if (Object.prototype.hasOwnProperty.call(attrs, k)) n.setAttribute(k, attrs[k]); }
    return n;
  }

  function measure(text, size) {
    try {
      if (!ctx) ctx = document.createElement('canvas').getContext('2d');
      ctx.font = '700 ' + size + 'px ' + FONT;
      return ctx.measureText(text).width;
    } catch (e) { return text.length * size * 0.65; }
  }

  function create(player) {
    var id = 'cj' + (++uid);
    var svg = node('svg', { viewBox: '0 0 ' + W + ' ' + H, 'class': 'jersey', role: 'img', preserveAspectRatio: 'xMidYMid meet' });
    var defs = node('defs', {});
    var filter = node('filter', { id: id + 'r', x: '-8%', y: '-8%', width: '116%', height: '116%' });
    filter.appendChild(node('feMorphology', { 'in': 'SourceAlpha', operator: 'erode', radius: '4', result: 'e1' }));
    filter.appendChild(node('feMorphology', { 'in': 'SourceAlpha', operator: 'erode', radius: '6', result: 'e2' }));
    filter.appendChild(node('feComposite', { 'in': 'e1', in2: 'e2', operator: 'out', result: 'line' }));
    var flood = node('feFlood', { 'flood-color': RING.burgundy, result: 'ink' });
    filter.appendChild(flood);
    filter.appendChild(node('feComposite', { 'in': 'ink', in2: 'line', operator: 'in', result: 'ring' }));
    var merge = node('feMerge', {});
    merge.appendChild(node('feMergeNode', { 'in': 'SourceGraphic' }));
    merge.appendChild(node('feMergeNode', { 'in': 'ring' }));
    filter.appendChild(merge);
    defs.appendChild(filter);
    svg.appendChild(defs);

    var img = node('image', { x: 0, y: 0, width: W, height: H, preserveAspectRatio: 'xMidYMid slice' });
    svg.appendChild(img);
    var name = node('text', { 'text-anchor': 'middle', fill: CREAM, 'font-weight': '700', 'font-family': FONT, 'class': 'jersey-name' });
    svg.appendChild(name);
    var numGroup = node('g', { transform: 'translate(' + CX + ' ' + NUM_BASE + ') scale(' + NUM_SQUEEZE + ' 1)' });
    var num = node('text', { x: 0, y: 0, 'text-anchor': 'middle', fill: CREAM, 'font-weight': '700', 'font-size': NUM_SIZE, 'font-family': FONT, filter: 'url(#' + id + 'r)', 'class': 'jersey-number' });
    numGroup.appendChild(num);
    svg.appendChild(numGroup);
    var crowns = node('g', { 'class': 'jersey-crowns' });
    svg.appendChild(crowns);

    svg.__j = { img: img, name: name, num: num, crowns: crowns, flood: flood, player: null };
    all.push(svg);
    update(svg, player);
    return svg;
  }

  function layout(svg) {
    var j = svg.__j;
    var p = j.player;
    if (!p) return;
    var label = String(p.name || '').toUpperCase();
    var size = NAME_SIZE, track = NAME_TRACK;
    var width = measure(label, size) + track * Math.max(0, label.length - 1);
    if (width > NAME_MAX) { var f = NAME_MAX / width; size *= f; track *= f; }
    var capHalf = size * 0.702 / 2;
    j.name.setAttribute('font-size', size.toFixed(2));
    j.name.setAttribute('letter-spacing', track.toFixed(2));
    j.name.setAttribute('x', (CX + track / 2).toFixed(2));
    j.name.setAttribute('y', (NAME_Y + capHalf).toFixed(2));

    var digits = String(p.number == null ? '' : p.number).split('');
    var adv = digits.map(function (d) { return measure(d, NUM_SIZE); });
    var total = adv.reduce(function (a, b) { return a + b; }, 0);
    var pos = -total / 2;
    while (j.crowns.firstChild) j.crowns.removeChild(j.crowns.firstChild);
    var ring = RING[p.jersey] || RING.burgundy;
    digits.forEach(function (d, i) {
      var cx = CX + (pos + adv[i] / 2) * NUM_SQUEEZE;
      pos += adv[i];
      var y = 518;
      j.crowns.appendChild(node('polygon', {
        points: [[cx - 11, y + 12], [cx - 11, y], [cx - 5, y + 6], [cx, y - 4], [cx + 5, y + 6], [cx + 11, y], [cx + 11, y + 12]].map(function (pt) { return pt.join(','); }).join(' '),
        fill: ring,
      }));
    });
  }

  function update(svg, player) {
    var j = svg.__j;
    j.player = player;
    var colour = BASES[player.jersey] ? player.jersey : 'burgundy';
    j.img.setAttributeNS(XL, 'href', ROOT + BASES[colour]);
    j.img.setAttribute('href', ROOT + BASES[colour]);
    j.flood.setAttribute('flood-color', RING[colour]);
    j.name.textContent = String(player.name || '').toUpperCase();
    j.num.textContent = String(player.number == null ? '' : player.number);
    svg.setAttribute('aria-label', player.name + ', number ' + player.number + ', back of the shirt');
    layout(svg);
  }

  function relayoutAll() {
    all = all.filter(function (s) { return s.isConnected; });
    all.forEach(layout);
  }

  if (document.fonts && document.fonts.load) {
    document.fonts.load('700 40px Poppins').then(relayoutAll, function () {});
    if (document.fonts.ready) document.fonts.ready.then(relayoutAll);
  }

  window.CrestJersey = { create: create, update: update, relayout: relayoutAll };
})();
