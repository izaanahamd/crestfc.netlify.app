(function () {
  'use strict';
  var form = document.getElementById('loginForm');
  var errorBox = document.getElementById('error');
  var submit = document.getElementById('submit');
  var password = document.getElementById('password');

  function showError(msg) { errorBox.textContent = msg; errorBox.hidden = false; }

  document.getElementById('toggle').addEventListener('click', function (e) {
    var show = password.type === 'password';
    password.type = show ? 'text' : 'password';
    e.currentTarget.textContent = show ? 'Hide' : 'Show';
    e.currentTarget.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
  });

  fetch('/api/session', { credentials: 'same-origin', cache: 'no-store' })
    .then(function (r) { return r.json(); })
    .then(function (s) {
      if (s.authenticated) { location.replace('./'); return; }
      if (!s.configured) document.getElementById('setupNote').hidden = false;
    })
    .catch(function () { /* the form still works */ });

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    errorBox.hidden = true;
    var email = document.getElementById('email').value.trim();
    if (!email || !password.value) { showError('Enter your email and password.'); return; }
    submit.disabled = true;
    submit.textContent = 'Signing in';
    fetch('/api/login', {
      method: 'POST', credentials: 'same-origin', cache: 'no-store',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: email, password: password.value })
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (body) { return { ok: r.ok, body: body }; });
    }).then(function (res) {
      if (res.ok) { location.replace('./'); return; }
      password.value = '';
      showError(res.body.message || 'Could not sign in. Please try again.');
      if (res.body.error === 'not_configured') document.getElementById('setupNote').hidden = false;
    }).catch(function () {
      showError('Could not reach the server. Check your internet and try again.');
    }).then(function () {
      submit.disabled = false;
      submit.textContent = 'Sign in';
    });
  });
})();
