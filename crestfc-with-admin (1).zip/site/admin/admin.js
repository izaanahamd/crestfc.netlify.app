/* CrestFC admin dashboard. Every change is saved on the server; this page only asks the server to save it. */
(function () {
  'use strict';

  // ---------- small helpers ----------
  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  function h(tag, props) {
    var el = document.createElement(tag);
    Object.keys(props || {}).forEach(function (k) {
      var v = props[k];
      if (v === null || v === undefined || v === false) return;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k.indexOf('on') === 0) el.addEventListener(k.slice(2), v);
      else if (k === 'list' || k === 'for' || k === 'role' || k.indexOf('aria-') === 0 || k.indexOf('data-') === 0) el.setAttribute(k, v === true ? '' : v);
      else if (k in el) el[k] = v;
      else el.setAttribute(k, v === true ? '' : v);
    });
    for (var i = 2; i < arguments.length; i++) {
      [].concat(arguments[i]).forEach(function (kid) {
        if (kid === null || kid === undefined || kid === false) return;
        el.appendChild(kid.nodeType ? kid : document.createTextNode(String(kid)));
      });
    }
    return el;
  }

  function toast(message, kind) {
    var t = h('div', { class: 'toast' + (kind === 'error' ? ' error' : ''), text: message, role: 'status' });
    $('#toasts').appendChild(t);
    setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, kind === 'error' ? 7000 : 4000);
  }

  function api(method, path, body) {
    var opts = { method: method, credentials: 'same-origin', cache: 'no-store', headers: {} };
    if (body !== undefined) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
    return fetch(path, opts).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) {
        if (res.status === 401) { location.replace('login.html'); throw new Error('signed out'); }
        return { ok: res.ok, status: res.status, data: data };
      });
    });
  }

  var state = { schema: null, players: null, matches: null, content: null, view: 'matches', dirty: false };

  // Saves one kind of data and updates what this page knows. Returns { ok, message }.
  function saveKind(kind, data) {
    return api('PUT', '/api/admin/' + kind, { rev: state[kind].rev, data: data }).then(function (r) {
      if (r.ok) { state[kind] = { rev: r.data.rev, data: r.data.data }; return { ok: true }; }
      if (r.status === 409 && r.data.current) { state[kind] = r.data.current; return { ok: false, conflict: true, message: r.data.message }; }
      return { ok: false, message: r.data.message || 'Could not save. Please try again.' };
    }).catch(function (err) {
      if (err && err.message === 'signed out') return { ok: false, message: 'Please sign in again.' };
      return { ok: false, message: 'Could not reach the server. Check your internet and try again.' };
    });
  }

  // ---------- dialogs ----------
  var dlg = $('#dlg');
  var dlgSubmit = null;
  function openForm(opts) {
    $('#dlgTitle').textContent = opts.title;
    $('#dlgBody').replaceChildren(opts.body);
    $('#dlgSave').textContent = opts.saveLabel || 'Save';
    dlgSubmit = opts.onSubmit;
    dlg.showModal();
  }
  $('#dlgForm').addEventListener('submit', function (e) {
    e.preventDefault();
    if (!dlgSubmit) return;
    var btn = $('#dlgSave'), label = btn.textContent;
    btn.disabled = true; btn.textContent = 'Saving';
    Promise.resolve(dlgSubmit()).then(function (done) { if (done === true) dlg.close(); }).then(function () {
      btn.disabled = false; btn.textContent = label;
    });
  });
  $('#dlgCancel').addEventListener('click', function () { dlg.close(); });
  $('#dlgX').addEventListener('click', function () { dlg.close(); });

  var confirmDlg = $('#confirm');
  var confirmAction = null;
  function openConfirm(opts) {
    $('#confirmTitle').textContent = opts.title;
    $('#confirmText').textContent = opts.text;
    $('#confirmError').hidden = true;
    $('#confirmOk').textContent = opts.okLabel || 'Delete';
    confirmAction = opts.onConfirm;
    confirmDlg.showModal();
  }
  $('#confirmCancel').addEventListener('click', function () { confirmDlg.close(); });
  $('#confirmOk').addEventListener('click', function () {
    var btn = $('#confirmOk'), label = btn.textContent;
    btn.disabled = true; btn.textContent = 'Working';
    Promise.resolve(confirmAction()).then(function (res) {
      if (res.ok) confirmDlg.close();
      else { $('#confirmError').textContent = res.message; $('#confirmError').hidden = false; }
    }).then(function () { btn.disabled = false; btn.textContent = label; });
  });

  function field(label, control, hint) {
    return h('div', { class: 'field' }, h('label', { class: 'lab', for: control.id, text: label }), control, hint || null);
  }

  // ---------- dates ----------
  function fmtDate(iso) {
    var p = iso.split('-');
    return new Date(+p[0], +p[1] - 1, +p[2]).toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
  }
  function fmtTime(t) {
    if (!t) return '';
    var hr = +t.slice(0, 2);
    return ((hr % 12) || 12) + ':' + t.slice(3, 5) + ' ' + (hr >= 12 ? 'PM' : 'AM');
  }
  function isPast(m) {
    var p = m.date.split('-'), t = (m.time || '23:59').split(':');
    return new Date(+p[0], +p[1] - 1, +p[2], +t[0], +t[1]) < new Date();
  }
  function sortKey(m) { return m.date + ' ' + (m.time || '00:00'); }

  // ---------- page pieces ----------
  function pageHead(title, buttonLabel, onClick) {
    return h('div', { class: 'page-head' }, h('h1', { text: title }), buttonLabel ? h('button', { class: 'btn', type: 'button', text: buttonLabel, onclick: onClick }) : null);
  }
  function emptyBox(title, text, buttonLabel, onClick) {
    return h('div', { class: 'empty' }, h('b', { text: title }), h('span', { text: text }), buttonLabel ? h('button', { class: 'btn', type: 'button', text: buttonLabel, onclick: onClick }) : null);
  }

  // ---------- matches ----------
  function matchTitle(m) { return m.venueType === 'away' ? m.opponent + ' vs CrestFC' : 'CrestFC vs ' + m.opponent; }

  function renderMatches() {
    var list = state.matches.data.slice();
    var upcoming = list.filter(function (m) { return m.status !== 'completed'; }).sort(function (a, b) { return sortKey(a) < sortKey(b) ? -1 : 1; });
    var results = list.filter(function (m) { return m.status === 'completed'; }).sort(function (a, b) { return sortKey(a) < sortKey(b) ? 1 : -1; });
    var out = [pageHead('Matches', 'Add match', function () { matchForm(null); }),
      h('p', { class: 'sub', text: 'Add upcoming matches and enter the score after the game. The Matches section shows on the website as soon as you save your first match.' })];
    if (!list.length) {
      out.push(emptyBox('No matches yet', 'Your website currently has no Matches section. Add a match and it appears right away.', 'Add your first match', function () { matchForm(null); }));
    } else {
      out.push(h('div', { class: 'section-title', text: 'Upcoming' }));
      out.push(upcoming.length ? h('div', { class: 'rows' }, upcoming.map(matchRow)) : h('p', { class: 'sub', text: 'No upcoming matches.' }));
      out.push(h('div', { class: 'section-title', text: 'Results' }));
      out.push(results.length ? h('div', { class: 'rows' }, results.map(matchRow)) : h('p', { class: 'sub', text: 'No results yet. Open a match after it is played and set it to Completed to enter the score.' }));
    }
    $('#view').replaceChildren.apply($('#view'), out);
  }

  function matchRow(m) {
    var p = m.date.split('-');
    var d = new Date(+p[0], +p[1] - 1, +p[2]);
    var bits = [fmtDate(m.date), fmtTime(m.time), m.venue, m.competition].filter(Boolean).join('  ·  ');
    var side = [];
    if (m.status === 'completed') {
      var win = m.ourScore > m.theirScore, draw = m.ourScore === m.theirScore;
      var away = m.venueType === 'away';
      side.push(h('span', { class: 'score', text: (away ? m.theirScore : m.ourScore) + ' – ' + (away ? m.ourScore : m.theirScore) }));
      side.push(h('span', { class: 'chip ' + (win ? 'win' : draw ? 'draw' : ''), text: win ? 'Win' : draw ? 'Draw' : 'Loss' }));
    } else if (m.status === 'postponed') {
      side.push(h('span', { class: 'chip warn', text: 'Postponed' }));
    } else {
      side.push(h('span', { class: 'chip', text: 'Upcoming' }));
      if (isPast(m)) side.push(h('span', { class: 'chip warn', text: 'Date passed' }));
    }
    return h('article', { class: 'row' },
      h('div', { class: 'datebox' }, h('div', {}, h('b', { text: String(d.getDate()) }), h('br'), h('span', { text: d.toLocaleDateString('en-GB', { month: 'short' }).toUpperCase() }))),
      h('div', { class: 'rowmain' }, h('h3', { text: matchTitle(m) }), h('p', { text: bits })),
      h('div', { class: 'rowside' }, side),
      h('div', { class: 'actions' },
        h('button', { class: 'btn ghost small', type: 'button', text: 'Edit', 'aria-label': 'Edit match against ' + m.opponent, onclick: function () { matchForm(m); } }),
        h('button', { class: 'btn ghost small', type: 'button', text: 'Delete', 'aria-label': 'Delete match against ' + m.opponent, onclick: function () { deleteMatch(m); } })));
  }

  function matchForm(existing) {
    var m = existing || { id: null, opponent: '', date: '', time: '', venue: '', competition: '', venueType: 'home', status: 'upcoming', ourScore: '', theirScore: '' };
    var L = state.schema.limits;
    var opponent = h('input', { id: 'f-opp', type: 'text', value: m.opponent, maxLength: L.opponent, required: true, autocomplete: 'off', placeholder: 'For example: Falcons FT' });
    var date = h('input', { id: 'f-date', type: 'date', value: m.date, required: true });
    var time = h('input', { id: 'f-time', type: 'time', value: m.time });
    var venue = h('input', { id: 'f-venue', type: 'text', value: m.venue, maxLength: L.venue, placeholder: 'Ground or hall name', autocomplete: 'off' });
    var comp = h('input', { id: 'f-comp', type: 'text', value: m.competition, maxLength: L.competition, list: 'comps', placeholder: 'Friendly, League, Cup', autocomplete: 'off' });
    var comps = h('datalist', { id: 'comps' }, ['Friendly', 'League', 'Cup', 'Tournament'].map(function (c) { return h('option', { value: c }); }));
    var venueType = h('select', { id: 'f-vt' }, [['home', 'Home'], ['away', 'Away'], ['neutral', 'Neutral ground']].map(function (o) { return h('option', { value: o[0], text: o[1], selected: m.venueType === o[0] }); }));
    var status = h('select', { id: 'f-status' }, [['upcoming', 'Upcoming'], ['completed', 'Completed (enter the score)'], ['postponed', 'Postponed']].map(function (o) { return h('option', { value: o[0], text: o[1], selected: m.status === o[0] }); }));
    var ours = h('input', { id: 'f-ours', type: 'number', min: 0, max: 99, step: 1, inputMode: 'numeric', value: m.ourScore === null ? '' : m.ourScore });
    var theirs = h('input', { id: 'f-theirs', type: 'number', min: 0, max: 99, step: 1, inputMode: 'numeric', value: m.theirScore === null ? '' : m.theirScore });
    var scores = h('div', { class: 'grid2' }, field('CrestFC goals', ours), field('Opponent goals', theirs));
    var err = h('p', { class: 'form-error', role: 'alert', hidden: true });
    function syncScores() { scores.hidden = status.value !== 'completed'; }
    status.addEventListener('change', syncScores); syncScores();

    var body = h('div', { class: 'dlg-body-inner', style: '' });
    body = h('div', { class: 'fields' }, field('Opponent', opponent), h('div', { class: 'grid2' }, field('Date', date), field('Time (optional)', time)),
      field('Venue', venue), h('div', { class: 'grid2' }, field('Competition (optional)', comp), field('Home or away', venueType)),
      field('Status', status), scores, comps, err);
    body.className = 'fields';
    body.style.display = 'grid'; body.style.gap = '16px';

    openForm({
      title: existing ? 'Edit match' : 'Add match',
      body: body,
      onSubmit: function () {
        err.hidden = true;
        function fail(msg) { err.textContent = msg; err.hidden = false; return false; }
        if (!opponent.value.trim()) return fail('Enter the opponent.');
        if (!date.value) return fail('Choose the match date.');
        var next = { id: m.id, opponent: opponent.value.trim(), date: date.value, time: time.value, venue: venue.value.trim(), competition: comp.value.trim(), venueType: venueType.value, status: status.value, ourScore: null, theirScore: null };
        if (next.status === 'completed') {
          if (ours.value === '' || theirs.value === '') return fail('Enter both scores for a completed match.');
          next.ourScore = Number(ours.value); next.theirScore = Number(theirs.value);
        }
        var all = state.matches.data.map(function (x) { return x.id === m.id ? next : x; });
        if (!existing) all.push(next);
        return saveKind('matches', all).then(function (r) {
          if (r.ok) { toast('Saved. The website is updated.'); renderMatches(); return true; }
          if (r.conflict) { renderMatches(); dlg.close(); toast(r.message, 'error'); return false; }
          return fail(r.message);
        });
      }
    });
    opponent.focus();
  }

  function deleteMatch(m) {
    openConfirm({
      title: 'Delete this match?',
      text: matchTitle(m) + ' on ' + fmtDate(m.date) + ' will be removed from the website. This cannot be undone.',
      onConfirm: function () {
        var all = state.matches.data.filter(function (x) { return x.id !== m.id; });
        return saveKind('matches', all).then(function (r) {
          if (r.ok) { toast('Match deleted.'); renderMatches(); return { ok: true }; }
          if (r.conflict) { renderMatches(); }
          return { ok: false, message: r.message };
        });
      }
    });
  }

  // ---------- players ----------
  function renderPlayers() {
    var list = state.players.data;
    var out = [pageHead('Players', 'Add player', function () { playerForm(null); }),
      h('p', { class: 'sub', text: 'Change names, shirt numbers, positions and profiles. Each shirt on the website is drawn from this list. Use the arrows to change the order.' })];
    var hasCaptain = list.some(function (p) { return p.captain; });
    if (!hasCaptain && list.length) out.push(h('div', { class: 'banner', text: 'No captain is chosen, so the Captain section is hidden on the website. Edit a player and tick "Captain" to show it.' }));
    if (!list.length) out.push(emptyBox('No players', 'The Squad section on the website is empty.', 'Add a player', function () { playerForm(null); }));
    else out.push(h('div', { class: 'players' }, list.map(playerCard)));
    $('#view').replaceChildren.apply($('#view'), out);
  }

  function playerCard(p, i) {
    var list = state.players.data;
    var thumb = h('div', { class: 'thumb' });
    if (window.CrestJersey) thumb.appendChild(window.CrestJersey.create(p));
    var chips = h('div', { class: 'chips' });
    if (p.captain) chips.appendChild(h('span', { class: 'chip cap', text: 'Captain' }));
    if (p.jersey === 'green') chips.appendChild(h('span', { class: 'chip green', text: 'Green shirt' }));
    if (p.profile) chips.appendChild(h('span', { class: 'chip', text: 'Has profile' }));
    function move(delta) {
      var next = list.slice(); var j = i + delta; var t = next[i]; next[i] = next[j]; next[j] = t;
      saveKind('players', next).then(function (r) {
        if (r.ok) toast('Order saved.'); else toast(r.message, 'error');
        renderPlayers();
      });
    }
    return h('article', { class: 'pcard' }, thumb,
      h('div', {}, h('div', { class: 'num', text: '#' + p.number }), h('h3', { text: p.name }), h('p', { text: p.position || 'No position set' }), chips),
      h('div', { class: 'actions' },
        h('button', { class: 'btn ghost small', type: 'button', text: 'Edit', 'aria-label': 'Edit ' + p.name, onclick: function () { playerForm(p); } }),
        h('button', { class: 'btn ghost small', type: 'button', text: 'Delete', 'aria-label': 'Delete ' + p.name, onclick: function () { deletePlayer(p); } }),
        h('span', { class: 'spacer' }),
        h('button', { class: 'iconbtn', type: 'button', text: '↑', 'aria-label': 'Move ' + p.name + ' up', disabled: i === 0, onclick: function () { move(-1); } }),
        h('button', { class: 'iconbtn', type: 'button', text: '↓', 'aria-label': 'Move ' + p.name + ' down', disabled: i === list.length - 1, onclick: function () { move(1); } })));
  }

  function playerForm(existing) {
    var p = existing || { id: null, name: '', number: '', position: '', profile: '', captain: false, jersey: 'burgundy' };
    var L = state.schema.limits;
    var name = h('input', { id: 'p-name', type: 'text', value: p.name, maxLength: L.playerName, required: true, autocomplete: 'off' });
    var number = h('input', { id: 'p-num', type: 'number', min: 0, max: 99, step: 1, inputMode: 'numeric', value: p.number, required: true });
    var position = h('input', { id: 'p-pos', type: 'text', value: p.position, maxLength: L.playerPosition, list: 'positions', autocomplete: 'off', placeholder: 'Choose or type a position' });
    var positions = h('datalist', { id: 'positions' }, state.schema.positions.map(function (x) { return h('option', { value: x }); }));
    var jersey = h('select', { id: 'p-jersey' }, [['burgundy', 'Burgundy'], ['green', 'Green']].map(function (o) { return h('option', { value: o[0], text: o[1], selected: p.jersey === o[0] }); }));
    var profile = h('textarea', { id: 'p-profile', maxLength: L.playerProfile, rows: 5, placeholder: 'A few lines about the player. Visitors can open this from the squad card.' });
    profile.value = p.profile;
    var count = h('small', { text: '' });
    var captainBox = h('input', { id: 'p-cap', type: 'checkbox', checked: p.captain });
    var captainNote = h('small', { text: '' });
    var numberNote = h('small', { text: '' });
    var err = h('p', { class: 'form-error', role: 'alert', hidden: true });

    var previewBox = h('div', { class: 'preview' });
    var svg = window.CrestJersey ? window.CrestJersey.create({ name: p.name || 'Name', number: p.number === '' ? 0 : p.number, jersey: p.jersey }) : null;
    if (svg) previewBox.appendChild(svg);
    function currentCaptainOther() {
      var o = state.players.data.filter(function (x) { return x.captain && x.id !== p.id; })[0];
      return o || null;
    }
    function refresh() {
      if (svg) window.CrestJersey.update(svg, { name: name.value.trim() || 'Name', number: number.value === '' ? 0 : number.value, jersey: jersey.value });
      count.textContent = profile.value.length + ' of ' + L.playerProfile + ' characters';
      var clash = number.value !== '' && state.players.data.filter(function (x) { return x.id !== p.id && String(x.number) === String(Number(number.value)); })[0];
      numberNote.textContent = clash ? 'Another player (' + clash.name + ') already wears this number.' : '';
      numberNote.className = clash ? 'warn' : '';
      var other = currentCaptainOther();
      captainNote.textContent = captainBox.checked && other ? other.name + ' is the captain now. Saving will make this player the captain instead.' : '';
      captainNote.className = captainNote.textContent ? 'warn' : '';
    }
    [name, number, jersey, profile, captainBox].forEach(function (c) { c.addEventListener('input', refresh); c.addEventListener('change', refresh); });
    refresh();

    var fields = h('div', { class: 'fields' },
      field('Name', name), h('div', { class: 'grid2' }, field('Shirt number', number, numberNote), field('Shirt colour', jersey)),
      field('Position', position), positions,
      field('Profile', profile, count),
      h('label', { class: 'check' }, captainBox, h('span', { text: 'Captain' })), captainNote, err);
    var body = h('div', { class: 'pform' }, previewBox, fields);

    openForm({
      title: existing ? 'Edit player' : 'Add player',
      body: body,
      onSubmit: function () {
        err.hidden = true;
        function fail(msg) { err.textContent = msg; err.hidden = false; return false; }
        if (!name.value.trim()) return fail('Enter the player\'s name.');
        if (number.value === '' || !(Number(number.value) >= 0 && Number(number.value) <= 99) || !Number.isInteger(Number(number.value))) return fail('Shirt number must be a whole number from 0 to 99.');
        var next = { id: p.id, name: name.value.trim(), number: Number(number.value), position: position.value.trim(), profile: profile.value.trim(), captain: captainBox.checked, jersey: jersey.value };
        var all = state.players.data.map(function (x) {
          if (x.id === p.id) return next;
          return next.captain && x.captain ? Object.assign({}, x, { captain: false }) : x;
        });
        if (!existing) all = all.map(function (x) { return next.captain && x.captain ? Object.assign({}, x, { captain: false }) : x; }).concat([next]);
        return saveKind('players', all).then(function (r) {
          if (r.ok) { toast('Saved. The website is updated.'); renderPlayers(); return true; }
          if (r.conflict) { renderPlayers(); dlg.close(); toast(r.message, 'error'); return false; }
          return fail(r.message);
        });
      }
    });
    name.focus();
  }

  function deletePlayer(p) {
    openConfirm({
      title: 'Delete ' + p.name + '?',
      text: p.name + ' (#' + p.number + ') will be removed from the squad on the website.' + (p.captain ? ' This player is the captain, so the Captain section will be hidden until you choose a new captain.' : '') + ' This cannot be undone.',
      onConfirm: function () {
        var all = state.players.data.filter(function (x) { return x.id !== p.id; });
        return saveKind('players', all).then(function (r) {
          if (r.ok) { toast('Player deleted.'); renderPlayers(); return { ok: true }; }
          if (r.conflict) renderPlayers();
          return { ok: false, message: r.message };
        });
      }
    });
  }

  // ---------- site content ----------
  function renderContent() {
    var fields = state.schema.fields;
    var saved = state.content.data;
    var def = {}; var saveBase = {};
    fields.forEach(function (f) { def[f.key] = f.default; saveBase[f.key] = typeof saved[f.key] === 'string' ? saved[f.key] : f.default; });
    var values = Object.assign({}, saveBase);
    var statusEl = h('p', { text: 'No unsaved changes.' });
    var saveBtn = h('button', { class: 'btn', type: 'button', text: 'Save changes', disabled: true });
    var discardBtn = h('button', { class: 'btn ghost', type: 'button', text: 'Cancel', disabled: true });
    var errEl = h('p', { class: 'form-error', role: 'alert', hidden: true });
    var resets = {};

    function isDirty() { return fields.some(function (f) { return values[f.key].trim() !== saveBase[f.key].trim(); }); }
    function sync() {
      var d = isDirty();
      state.dirty = d;
      statusEl.textContent = d ? 'You have unsaved changes.' : 'No unsaved changes.';
      statusEl.className = d ? 'dirty' : '';
      saveBtn.disabled = !d; discardBtn.disabled = !d;
      fields.forEach(function (f) { resets[f.key].disabled = values[f.key].trim() === def[f.key]; });
    }

    var groups = [];
    fields.forEach(function (f) { if (groups.indexOf(f.group) < 0) groups.push(f.group); });
    var groupEls = groups.map(function (g, gi) {
      var body = h('div', { class: 'gbody' });
      fields.filter(function (f) { return f.group === g; }).forEach(function (f) {
        var id = 'c-' + f.key.replace(/\./g, '-');
        var control = f.multiline
          ? h('textarea', { id: id, rows: 3, maxLength: f.max })
          : h('input', { id: id, type: f.type === 'url' ? 'url' : f.type === 'phone' ? 'tel' : 'text', maxLength: f.max, autocomplete: 'off' });
        control.value = values[f.key];
        control.addEventListener('input', function () { values[f.key] = control.value; sync(); });
        var reset = h('button', { type: 'button', text: 'Use the original text', onclick: function () { control.value = def[f.key]; values[f.key] = def[f.key]; sync(); } });
        resets[f.key] = reset;
        body.appendChild(h('div', { class: 'cfield' }, h('div', { class: 'lab' }, h('label', { for: id }, h('span', { text: f.label })), reset), control, f.help ? h('small', { text: f.help }) : null));
      });
      return h('details', { class: 'group', open: gi === 0 }, h('summary', { text: g }), body);
    });

    saveBtn.addEventListener('click', function () {
      errEl.hidden = true;
      var overrides = {};
      fields.forEach(function (f) { var v = values[f.key].replace(/\r\n/g, '\n').trim(); if (v && v !== f.default) overrides[f.key] = v; });
      saveBtn.disabled = true; saveBtn.textContent = 'Saving';
      saveKind('content', overrides).then(function (r) {
        saveBtn.textContent = 'Save changes';
        if (r.ok) { toast('Saved. The website is updated.'); state.dirty = false; renderContent(); return; }
        if (r.conflict) { state.dirty = false; renderContent(); toast(r.message, 'error'); return; }
        errEl.textContent = r.message; errEl.hidden = false; sync();
      });
    });
    discardBtn.addEventListener('click', function () { state.dirty = false; renderContent(); toast('Changes discarded.'); });

    var bar = h('div', { class: 'savebar' }, h('div', { class: 'wrap' }, statusEl, h('div', { class: 'btns' }, discardBtn, saveBtn)));
    var out = [pageHead('Site content'),
      h('p', { class: 'sub', text: 'Edit the words on your website. If you clear a box or press "Use the original text", the website goes back to the original wording.' }),
      errEl].concat(groupEls).concat([bar]);
    $('#view').replaceChildren.apply($('#view'), out);
    sync();
  }

  // ---------- navigation ----------
  function show(view) {
    if (['matches', 'players', 'content'].indexOf(view) < 0) view = 'matches';
    if (state.dirty && view !== state.view) {
      toast('Save or cancel your changes before leaving this page.', 'error');
      return;
    }
    state.view = view;
    document.querySelectorAll('.tab').forEach(function (t) { t.setAttribute('aria-selected', t.getAttribute('data-view') === view ? 'true' : 'false'); });
    if (location.hash !== '#' + view) history.replaceState(null, '', '#' + view);
    if (view === 'matches') renderMatches(); else if (view === 'players') renderPlayers(); else renderContent();
    window.scrollTo(0, 0);
  }
  document.querySelectorAll('.tab').forEach(function (t) { t.addEventListener('click', function () { show(t.getAttribute('data-view')); }); });
  window.addEventListener('beforeunload', function (e) { if (state.dirty) { e.preventDefault(); e.returnValue = ''; } });

  $('#signOut').addEventListener('click', function () {
    if (state.dirty) { toast('Save or cancel your changes first.', 'error'); return; }
    api('POST', '/api/logout', {}).then(function () { location.replace('login.html'); }, function () { location.replace('login.html'); });
  });

  // ---------- start ----------
  api('GET', '/api/session').then(function (s) {
    if (!s.data.authenticated) { location.replace('login.html'); return null; }
    return Promise.all([api('GET', '/api/schema'), api('GET', '/api/content')]);
  }).then(function (res) {
    if (!res) return;
    state.schema = res[0].data;
    var c = res[1].data;
    state.players = { rev: c.rev.players, data: c.players };
    state.matches = { rev: c.rev.matches, data: c.matches };
    state.content = { rev: c.rev.content, data: c.content };
    show(location.hash.slice(1) || 'matches');
  }).catch(function (e) {
    if (e && e.message === 'signed out') return;
    $('#view').replaceChildren(h('div', { class: 'banner', text: 'Could not load the admin data. Check your internet connection and reload the page.' }));
  });
})();
