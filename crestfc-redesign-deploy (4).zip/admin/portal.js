import {fields, defaults, validateContent} from '/assets/content.js';
const $ = id => document.getElementById(id);
let original, callback, submitting = false;
const params = new URLSearchParams(location.hash.slice(1));
if (params.has('invite_token')) callback = {action:'invite',token:params.get('invite_token')};
if (params.has('recovery_token')) callback = {action:'reset',token:params.get('recovery_token')};
if (callback) history.replaceState(null,'',location.pathname);
function status(message) { $('status').textContent = message; }
async function api(path, method='GET', body) {
 const response = await fetch(path,{method,credentials:'same-origin',headers:body ? {'Content-Type':'application/json'} : {},body:body ? JSON.stringify(body) : undefined});
 let data; try { data = await response.json(); } catch { throw new Error('The service is unavailable. Please try again.'); }
 if (!response.ok) throw new Error(data.error || 'Please try again.');
 return data;
}
function collect() {
 const form = new FormData($('content-form'));
 return {...Object.fromEntries(fields.map(([key]) => [key,form.get(key)])),squad:original.content.squad.map((p,i) => ({n:p.n,name:form.get('name'+i),pos:form.get('pos'+i)}))};
}
function dirty() {
 const changed = JSON.stringify(collect()) !== JSON.stringify(original.content);
 $('save').disabled = !changed || submitting; $('discard').disabled = !changed || submitting;
 $('dirty').textContent = submitting ? 'Publishing…' : changed ? 'Unpublished edits' : 'All changes saved';
 return changed;
}
function input(label, name, value, long=false) {
 const wrapper = document.createElement('label'); wrapper.textContent = label;
 if (long) wrapper.className='wide';
 const element = document.createElement(long?'textarea':'input'); element.name=name; element.value=value; element.required=true; element.maxLength=name.startsWith('name')||name.startsWith('pos')?80:1000;
 wrapper.append(element); return wrapper;
}
function render() {
 $('sections').replaceChildren();
 const groups = ['Home','Captain','Squad','Website','Contact'];
 groups.forEach((group,i) => {
  const section=document.createElement('section'); section.className='panel'; section.id=group.toLowerCase();
  section.innerHTML=`<div class="section-head"><span class="index">0${i+1}</span><div><h2>${group}</h2><p>${group==='Squad'?'Update player names and positions. Shirt images stay as they are.':'Edit the text displayed on the public website.'}</p></div></div>`;
  const grid=document.createElement('div'); grid.className=group==='Squad'?'players':'field-grid';
  if(group==='Squad') original.content.squad.forEach((p,j)=> {
   const row=document.createElement('div'); row.className='player';
   const n=document.createElement('span'); n.className='shirt'; n.textContent=String(p.n).padStart(2,'0'); row.append(n,input('Player name','name'+j,p.name),input('Position','pos'+j,p.pos)); grid.append(row);
  });
  else fields.filter(f=>f[4]===group).forEach(([key,label])=>grid.append(input(label,key,original.content[key],/Text|Bio/.test(key))));
  section.append(grid); $('sections').append(section);
 });
 $('saved').textContent=original.updatedAt?'Last published '+new Date(original.updatedAt).toLocaleString():'Original website content · ready to edit';
 dirty();
}
async function init() {
 try {
  if(callback) {
   $('email-label').hidden=true; $('login-form').email.required=false;
   $('login-form').password.minLength=10; $('login-form').password.autocomplete='new-password';
   $('login-submit').textContent='Set password →'; $('forgot').hidden=true;
   status('Choose a password of at least 10 characters.'); return;
  }
  const session=await api('/api/auth'); $('logout').hidden=!session.signedIn;
  if(!session.authorized) { if(session.signedIn) status('This account needs the admin role. Ask the project owner to assign webmaster access in Netlify Identity.'); return; }
  original=await api('/api/content'); original.content={...defaults(),...original.content};
  render(); $('signin').hidden=true; $('editor').hidden=false;
 } catch(e) { status(e.message); }
}
$('login-form').addEventListener('submit',async e=>{
 e.preventDefault(); $('login-submit').disabled=true; status('Signing in…');
 try {
  await api('/api/auth','POST',{action:'login',email:e.target.email.value,password:e.target.password.value,...callback});
  location.replace('/admin/');
 } catch(e) { status(e.message); $('login-submit').disabled=false; }
});
$('forgot').onclick=async()=>{
 const email=$('login-form').email;
 if(!email.value || !email.reportValidity()) { status('Enter your email address to request a password reset.'); return; }
 $('forgot').disabled=true;
 try { await api('/api/auth','POST',{action:'recovery',email:email.value}); status('If this address has an account, check your inbox for a reset link.'); } catch(e){status(e.message);} finally{$('forgot').disabled=false;}
};
$('logout').onclick=async()=>{try { await api('/api/auth','POST',{action:'logout'}); location.replace('/admin/'); }catch(e){status(e.message);}};
$('content-form').oninput=dirty;
$('discard').onclick=()=>{render();status('Edits discarded.');};
$('content-form').onsubmit=async e=>{
 e.preventDefault(); let content;
 try{content=validateContent(collect());}catch(e){status(e.message);return;}
 submitting=true;dirty(); $('content-form').querySelectorAll('input,textarea').forEach(el=>el.disabled=true); status('Publishing website changes…');
 try{original=await api('/api/content','PUT',content);render();status('Published. Your website now displays the saved content.');}
 catch(e){status(e.message);}finally{submitting=false; $('content-form').querySelectorAll('input,textarea').forEach(el=>el.disabled=false); dirty();}
};
window.addEventListener('beforeunload',e=>{if(original && dirty()){e.preventDefault();e.returnValue='';}});
init();
