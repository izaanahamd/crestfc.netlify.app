export const fields = [
  ['headline', 'Club name', '.hero h1', 'CrestFC', 'Home'],
  ['eyebrow', 'Introduction', '.hero-copy > .eyebrow', 'More than a team', 'Home'],
  ['line1', 'Slogan · first line', '.slogan span:nth-child(1)', 'One team.', 'Home'],
  ['line2', 'Slogan · second line', '.slogan span:nth-child(2)', 'One crest.', 'Home'],
  ['line3', 'Slogan · third line', '.slogan span:nth-child(3)', 'One mission.', 'Home'],
  ['captainBio', 'Captain biography', '.cap-copy > p', "Meet our captain, the leader of CrestFC. With passion, teamwork, and determination, he inspires the team to give their best in every match. Together, we aim to achieve greatness on and off the pitch.", 'Captain'],
  ['galleryText', 'Gallery introduction', '#gallery .lede', 'Matchday photos and celebrations are added here once the games are played.', 'Website'],
  ['kitText', 'Kit description', '#jersey .spec', "Long-sleeve burgundy shirt with cream side panels and shoulder trim. The crest sits on the chest. On the back, a crown above the player's name and a cream number.", 'Website'],
  ['contactText', 'Contact introduction', '#contact .lede', 'Call the team or follow us on Instagram for match announcements and news.', 'Contact'],
  ['phone', 'Phone number', '#phone', '+92 321 8850554', 'Contact'],
  ['instagram', 'Instagram username (without @)', '', 'crestfc2026', 'Contact'],
];
export const squad = [
 {n:7,name:'Izaan',pos:'Left midfield'}, {n:23,name:'Aiyan',pos:'Goalkeeper'},
 {n:18,name:'Niazi',pos:'Centre back'}, {n:8,name:'Shayaan',pos:'Centre back'},
 {n:10,name:'Isa',pos:'Right midfield'}, {n:9,name:'Fazeel',pos:'Attacking midfield'},
 {n:17,name:'Muhammed',pos:'Striker'}
];
export function defaults() { return { ...Object.fromEntries(fields.map(f => [f[0], f[3]])), squad: squad.map(p => ({...p})) }; }
export function validateContent(value) {
 if (!value || typeof value !== 'object') throw new Error('Invalid website content.');
 const result = {};
 for (const [key, label] of fields) {
  if (typeof value[key] !== 'string' || !value[key].trim() || value[key].length > 1000) throw new Error(label + ' must contain 1–1,000 characters.');
  result[key] = value[key].trim();
 }
 if (!/^[a-zA-Z0-9_.]{1,30}$/.test(result.instagram)) throw new Error('Enter a valid Instagram username.');
 if (!/^\+?[\d\s()-]{6,30}$/.test(result.phone)) throw new Error('Enter a valid phone number.');
 if (!Array.isArray(value.squad) || value.squad.length !== squad.length) throw new Error('Invalid squad.');
 result.squad = value.squad.map((p, i) => {
  if (p.n !== squad[i].n || typeof p.name !== 'string' || !p.name.trim() || p.name.length > 80 || typeof p.pos !== 'string' || !p.pos.trim() || p.pos.length > 80) throw new Error('Player names and positions must contain 1–80 characters.');
  return { n:p.n, name:p.name.trim(), pos:p.pos.trim() };
 });
 return result;
}
