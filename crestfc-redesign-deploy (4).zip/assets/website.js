import {fields} from './content.js';
// Invitation and recovery emails may return to the homepage.
const callback = new URLSearchParams(location.hash.slice(1));
if(callback.has('invite_token') || callback.has('recovery_token')) location.replace('/admin/'+location.hash);
else fetch('/api/content',{cache:'no-store'}).then(r=>{if(!r.ok)throw new Error();return r.json();}).then(({content})=>{
 for(const [key,,selector] of fields) if(selector && typeof content[key]==='string') document.querySelectorAll(selector).forEach(el=>el.textContent=content[key]);
 if(content.headline) document.title=content.headline+' | Futsal Club';
 document.querySelector('.slogan')?.setAttribute('aria-label',[content.line1,content.line2,content.line3].join(' '));
 if(content.phone) document.querySelectorAll('a[href^="tel:"]').forEach(a=>a.href='tel:'+content.phone.replace(/[^+\d]/g,''));
 if(/^[a-zA-Z0-9_.]{1,30}$/.test(content.instagram)) {
  document.querySelectorAll('a[href*="instagram.com"]').forEach(a=>a.href='https://www.instagram.com/'+content.instagram+'/');
  document.querySelector('#contact .ccard:last-child .val').textContent='@'+content.instagram;
  document.querySelectorAll('[data-ig-handle]').forEach(el=>el.textContent='@'+content.instagram);
 }
 if(Array.isArray(content.squad)) {
  const cards=document.querySelectorAll('#squadGrid .card');
  content.squad.forEach((p,i)=>{
   const card=cards[i]; if(!card)return;
   card.querySelector('h3').textContent=p.name; card.querySelector('.meta p').textContent=p.pos;
  });
  const captain=content.squad.find(p=>p.n===7);
  if(captain) document.querySelector('.cap-name').textContent=captain.name;
  if(captain) document.querySelectorAll('[data-captain-pos]').forEach(el=>el.textContent=captain.pos);
  if(captain) document.querySelectorAll('[data-captain-name]').forEach(el=>el.textContent=captain.name);
 }
}).catch(()=>{/* Keep the original website visible when the content service is unavailable. */});
